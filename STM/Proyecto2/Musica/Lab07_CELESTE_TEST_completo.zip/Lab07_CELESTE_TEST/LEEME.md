# Descargar y cargar la Nucleo de audio

Descomprimir `Lab07_CELESTE_TEST_completo.zip`. El ZIP incluye fuentes, drivers
HAL/CMSIS, startup, linker, .ioc, metadatos de CubeIDE y firmware compilado.

1. En STM32CubeIDE: File > Import > General > Existing Projects into Workspace.
2. Seleccionar la carpeta descomprimida que contiene Lab07_CELESTE_TEST.
3. Marcar el proyecto Lab07_CELESTE_TEST y finalizar la importacion.
4. Compilar con Project > Build Project.
5. Conectar la Nucleo-F446RE por el USB del ST-LINK y usar Run o Debug para
   programarla. Si se usa Debug, pulsar Resume para que empiece el programa.

Alternativa sin compilar: el archivo Firmware/Lab07_CELESTE_TEST.elf ya esta
compilado para STM32F446RE. Se puede programar con STM32CubeProgrammer por
ST-LINK usando ese ELF. No es firmware para la Nucleo que ejecuta el juego:
se carga en la Nucleo dedicada a audio.

El arranque queda en silencio. USART2 recibe ASCII `1` para main_theme en loop,
`2` para main_menu en loop y `0` para detener, a 115200, 8N1. TX de la Nucleo
del juego a PA3 de la Nucleo de audio y GND comun. Salida DAC en PA4.
No se requieren las herramientas de Python usadas para preparar esta entrega.
Verificacion de compilacion y enlace completa; prueba fisica pendiente.
