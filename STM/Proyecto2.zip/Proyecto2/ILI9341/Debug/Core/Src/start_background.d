Core/Src/start_background.o: ../Core/Src/start_background.c \
 ../Core/Inc/start_background.h
../Core/Inc/start_background.h:
