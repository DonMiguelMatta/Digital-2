Core/Src/graficos.o: ../Core/Src/graficos.c ../Core/Inc/pgmspace.h \
 ../Core/Inc/graficos.h
../Core/Inc/pgmspace.h:
../Core/Inc/graficos.h:
