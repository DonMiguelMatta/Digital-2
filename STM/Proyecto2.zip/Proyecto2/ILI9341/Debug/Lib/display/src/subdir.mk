################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Lib/display/src/font.c \
../Lib/display/src/ili9341.c 

OBJS += \
./Lib/display/src/font.o \
./Lib/display/src/ili9341.o 

C_DEPS += \
./Lib/display/src/font.d \
./Lib/display/src/ili9341.d 


# Each subdirectory must supply rules for building sources it contributes
Lib/display/src/%.o Lib/display/src/%.su Lib/display/src/%.cyclo: ../Lib/display/src/%.c Lib/display/src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Lib/display/inc -I../Lib/SD -I../Lib/ControlesJugadores -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../FATFS/Target -I../FATFS/App -I../Middlewares/Third_Party/FatFs/src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Lib-2f-display-2f-src

clean-Lib-2f-display-2f-src:
	-$(RM) ./Lib/display/src/font.cyclo ./Lib/display/src/font.d ./Lib/display/src/font.o ./Lib/display/src/font.su ./Lib/display/src/ili9341.cyclo ./Lib/display/src/ili9341.d ./Lib/display/src/ili9341.o ./Lib/display/src/ili9341.su

.PHONY: clean-Lib-2f-display-2f-src

