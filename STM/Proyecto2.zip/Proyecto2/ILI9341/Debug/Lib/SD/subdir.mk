################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Lib/SD/fatfs_sd.c 

OBJS += \
./Lib/SD/fatfs_sd.o 

C_DEPS += \
./Lib/SD/fatfs_sd.d 


# Each subdirectory must supply rules for building sources it contributes
Lib/SD/%.o Lib/SD/%.su Lib/SD/%.cyclo: ../Lib/SD/%.c Lib/SD/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Lib/display/inc -I../Lib/SD -I../Lib/ControlesJugadores -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../FATFS/Target -I../FATFS/App -I../Middlewares/Third_Party/FatFs/src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Lib-2f-SD

clean-Lib-2f-SD:
	-$(RM) ./Lib/SD/fatfs_sd.cyclo ./Lib/SD/fatfs_sd.d ./Lib/SD/fatfs_sd.o ./Lib/SD/fatfs_sd.su

.PHONY: clean-Lib-2f-SD

