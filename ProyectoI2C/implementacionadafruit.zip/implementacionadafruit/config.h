/*
 * Configuracion privada para Adafruit IO
 * Este archivo se mantiene fuera de Git.
 */

#ifndef CONFIG_H_
#define CONFIG_H_

#define IO_USERNAME "Don22993"
#define IO_KEY      "aio_YLNB64MZRprknfEZf328xEP8BjxJ"
#define WIFI_SSID   "Redmi15"
#define WIFI_PASS   "12345678"

#include "AdafruitIO_WiFi.h"

AdafruitIO_WiFi io(IO_USERNAME, IO_KEY, WIFI_SSID, WIFI_PASS);

#endif /* CONFIG_H_ */
