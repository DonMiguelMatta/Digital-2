/*
 * Configuracion privada para Adafruit IO
 * Copiar como config.h y completar antes de compilar.
 */

#ifndef CONFIG_H_
#define CONFIG_H_

#define IO_USERNAME "usuario"
#define IO_KEY      "aio_clave_nueva"
#define WIFI_SSID   "red_wifi"
#define WIFI_PASS   "clave_wifi"

#include "AdafruitIO_WiFi.h"

AdafruitIO_WiFi io(IO_USERNAME, IO_KEY, WIFI_SSID, WIFI_PASS);

#endif /* CONFIG_H_ */
