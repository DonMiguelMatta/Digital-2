/*
 * Transporte I2C/TWI para el Master ATmega328P.
 * SDA = PC4, SCL = PC5.
 */

#ifndef I2CLIB_H_
#define I2CLIB_H_

#include <stdint.h>

#define I2C_FRAME_SIZE 8U

typedef enum
{
    I2C_ERROR_NONE = 0,
    I2C_ERROR_NULL_POINTER,
    I2C_ERROR_START,
    I2C_ERROR_ADDRESS_NACK,
    I2C_ERROR_DATA_NACK,
    I2C_ERROR_READ,
    I2C_ERROR_TIMEOUT,
    I2C_ERROR_STOP_TIMEOUT,
    I2C_ERROR_RESPONSE_TIMEOUT
} I2CError;

typedef enum
{
    I2C_EXCHANGE_IMMEDIATE = 0,
    I2C_EXCHANGE_DEFERRED = 1
} I2CExchangeMode;

void I2C_Master_Init(uint32_t scl_clock, uint8_t prescaler);

/* Primitivas conservadas para dispositivos como el VL53L0X. */
uint8_t I2C_Master_Start(void);
uint8_t I2C_Master_RepeatedStart(void);
void I2C_Master_Stop(void);
uint8_t I2C_Master_Write(uint8_t data);
uint8_t I2C_Master_Read(uint8_t *data, uint8_t ack);

/* Transporte generico de tramas fijas. */
uint8_t I2C_Master_ProbeAddress(uint8_t address);
uint8_t I2C_Master_Ping(uint8_t address,
                        const uint8_t request[I2C_FRAME_SIZE],
                        uint8_t response[I2C_FRAME_SIZE]);
uint8_t I2C_Master_Exchange(uint8_t address,
                            const uint8_t request[I2C_FRAME_SIZE],
                            uint8_t response[I2C_FRAME_SIZE],
                            I2CExchangeMode mode);

uint8_t I2C_Master_GetLastStatus(void);
I2CError I2C_Master_GetLastError(void);

#endif /* I2CLIB_H_ */
