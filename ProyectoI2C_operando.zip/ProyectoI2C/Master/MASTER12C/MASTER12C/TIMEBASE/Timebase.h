#ifndef TIMEBASE_H_
#define TIMEBASE_H_

#include <stdint.h>

void Timebase_Init(void);
uint32_t Timebase_Millis(void);

#endif
