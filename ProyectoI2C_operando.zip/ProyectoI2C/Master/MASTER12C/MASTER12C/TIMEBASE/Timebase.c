#include "Timebase.h"

#include <avr/interrupt.h>
#include <avr/io.h>
#include <util/atomic.h>

static volatile uint32_t timebase_milliseconds = 0UL;

void Timebase_Init(void)
{
    TCCR0A = (1U << WGM01);
    TCCR0B = (1U << CS01) | (1U << CS00);
    OCR0A = 249U;
    TCNT0 = 0U;
    TIMSK0 |= (1U << OCIE0A);
}

uint32_t Timebase_Millis(void)
{
    uint32_t milliseconds;

    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        milliseconds = timebase_milliseconds;
    }

    return milliseconds;
}

ISR(TIMER0_COMPA_vect)
{
    timebase_milliseconds++;
}
