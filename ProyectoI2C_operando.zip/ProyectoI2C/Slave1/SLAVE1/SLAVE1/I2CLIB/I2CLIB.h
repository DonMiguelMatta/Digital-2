/* Transporte I2C/TWI para un Slave ATmega328P. */

#ifndef I2CLIB_H_
#define I2CLIB_H_

#include <stdint.h>

#define I2C_FRAME_SIZE 8U

typedef enum
{
    I2C_SLAVE_REQUEST_NONE = 0,
    I2C_SLAVE_REQUEST_READY,
    I2C_SLAVE_REQUEST_REJECTED_BUSY
} I2CSlaveRequestState;

uint8_t I2C_Slave_Init(uint8_t address);
uint8_t I2C_Slave_RequestAvailable(void);
I2CSlaveRequestState I2C_Slave_GetRequest(uint8_t frame[I2C_FRAME_SIZE]);
uint8_t I2C_Slave_SetResponse(const uint8_t frame[I2C_FRAME_SIZE]);

#endif /* I2CLIB_H_ */
