#ifndef F_CPU
#define F_CPU 16000000UL
#endif

#include <avr/interrupt.h>
#include <avr/io.h>
#include <stdint.h>
#include <util/delay.h>

#include "HCR/HC_SR04.h"
#include "I2CLIB/I2CLIB.h"
#include "PROTOCOL/Protocol.h"
#include "SERVO/Servo.h"

#define SLAVE1_I2C_ADDRESS 0x11U
#define SLAVE1_DC_LED_PIN PB1
#define SLAVE1_SAMPLE_INTERVAL_MS 60U

typedef struct
{
    uint8_t valid;
    uint16_t echo_us;
    uint8_t counter;
} HCSR04RawSample;

static HCSR04RawSample hcsr04_sample =
{
    0U,
    HCSR04_INVALID_PULSE_US,
    0U
};

static uint8_t dc_direction = (uint8_t)PROTOCOL_DIRECTION_FORWARD;
static uint8_t dc_pwm = 0U;

static uint8_t Slave1_SendResponse(const ProtocolResponse *response)
{
    uint8_t frame[PROTOCOL_FRAME_SIZE];

    Protocol_EncodeResponse(response, frame);
    return I2C_Slave_SetResponse(frame);
}

static uint8_t Slave1_SendStatus(const ProtocolRequest *request,
                                 ProtocolStatus status)
{
    ProtocolResponse response;

    (void)Protocol_CreateResponse(&response,
                                  request->command,
                                  request->device,
                                  status,
                                  0U,
                                  0);
    return Slave1_SendResponse(&response);
}

static void Slave1_SetDcState(uint8_t direction, uint8_t pwm)
{
    dc_direction = direction;
    dc_pwm = pwm;

    if (dc_pwm > 0U)
    {
        PORTB |= (1U << SLAVE1_DC_LED_PIN);
    }
    else
    {
        PORTB &= (uint8_t)~(1U << SLAVE1_DC_LED_PIN);
    }
}

static void Slave1_HandlePing(const ProtocolRequest *request)
{
    ProtocolResponse response;
    uint8_t data[PROTOCOL_RESPONSE_DATA_SIZE] = {0U, 0U, 0U, 0U};
    uint8_t length = 0U;
    ProtocolStatus status = OK;

    switch ((ProtocolDevice)request->device)
    {
        case HCSR04:
        case ALL_LOCAL_ACTUATORS:
            break;

        case SERVO_WATER:
            data[0] = Servo_GetAngle();
            length = 1U;
            break;

        case DC_MOTOR:
            data[0] = dc_direction;
            data[1] = dc_pwm;
            data[2] = (uint8_t)((PORTB &
                       (1U << SLAVE1_DC_LED_PIN)) != 0U);
            length = 3U;
            break;

        case SERVO_DOOR:
            status = UNSUPPORTED;
            break;

        case IR:
        case STEPPER:
        default:
            status = UNKNOWN_DEVICE;
            break;
    }

    (void)Protocol_CreateResponse(&response,
                                  request->command,
                                  request->device,
                                  status,
                                  length,
                                  data);
    (void)Slave1_SendResponse(&response);
}

static void Slave1_HandleSensorRead(const ProtocolRequest *request)
{
    ProtocolResponse response;
    uint8_t data[PROTOCOL_RESPONSE_DATA_SIZE];
    ProtocolStatus status;

    if (request->device != (uint8_t)HCSR04)
    {
        (void)Slave1_SendStatus(request, UNKNOWN_DEVICE);
        return;
    }

    data[0] = hcsr04_sample.valid;
    data[1] = (uint8_t)(hcsr04_sample.echo_us >> 8U);
    data[2] = (uint8_t)hcsr04_sample.echo_us;
    data[3] = hcsr04_sample.counter;
    status = (hcsr04_sample.valid != 0U) ? OK : NO_SAMPLE;

    (void)Protocol_CreateResponse(&response,
                                  request->command,
                                  request->device,
                                  status,
                                  PROTOCOL_RESPONSE_DATA_SIZE,
                                  data);
    (void)Slave1_SendResponse(&response);
}

static void Slave1_HandleValidatedRequest(const ProtocolRequest *request)
{
    switch ((ProtocolCommand)request->command)
    {
        case CMD_PING:
            Slave1_HandlePing(request);
            break;

        case CMD_READ_SENSOR:
            Slave1_HandleSensorRead(request);
            break;

        case CMD_SERVO_POSITION:
            if (request->device == (uint8_t)SERVO_DOOR)
            {
                (void)Slave1_SendStatus(request, UNSUPPORTED);
            }
            else if (request->device != (uint8_t)SERVO_WATER)
            {
                (void)Slave1_SendStatus(request, UNKNOWN_DEVICE);
            }
            else if (Slave1_SendStatus(request, ACCEPTED) != 0U)
            {
                (void)Servo_SetAngle(request->data[0]);
            }
            break;

        case CMD_DC_MOTOR:
            if (request->device != (uint8_t)DC_MOTOR)
            {
                (void)Slave1_SendStatus(request, UNKNOWN_DEVICE);
            }
            else if (Slave1_SendStatus(request, ACCEPTED) != 0U)
            {
                Slave1_SetDcState(request->data[0], request->data[1]);
            }
            break;

        case CMD_STEPPER_MOVE:
            (void)Slave1_SendStatus(request, UNKNOWN_DEVICE);
            break;

        case CMD_STOP:
            if ((request->device == (uint8_t)DC_MOTOR) ||
                (request->device == (uint8_t)ALL_LOCAL_ACTUATORS))
            {
                if (Slave1_SendStatus(request, ACCEPTED) != 0U)
                {
                    Slave1_SetDcState(dc_direction, 0U);
                    if (request->device ==
                        (uint8_t)ALL_LOCAL_ACTUATORS)
                    {
                        (void)Servo_SetAngle(0U);
                    }
                }
            }
            else
            {
                (void)Slave1_SendStatus(request, UNKNOWN_DEVICE);
            }
            break;

        default:
            (void)Slave1_SendStatus(request, UNKNOWN_COMMAND);
            break;
    }
}

static void Slave1_ServiceI2C(void)
{
    uint8_t frame[PROTOCOL_FRAME_SIZE];
    I2CSlaveRequestState request_state;
    ProtocolRequest request;
    ProtocolStatus validation;

    if (I2C_Slave_RequestAvailable() == 0U)
    {
        return;
    }

    request_state = I2C_Slave_GetRequest(frame);
    if (request_state == I2C_SLAVE_REQUEST_NONE)
    {
        return;
    }

    validation = Protocol_DecodeRequest(frame, &request);

    if (request_state == I2C_SLAVE_REQUEST_REJECTED_BUSY)
    {
        (void)Slave1_SendStatus(&request, BUSY);
        return;
    }

    if (validation != OK)
    {
        (void)Slave1_SendStatus(&request, validation);
        return;
    }

    Slave1_HandleValidatedRequest(&request);
}

static void Slave1_UpdateSensor(void)
{
    uint16_t echo_us = HCSR04_INVALID_PULSE_US;

    if (HCSR04_ReadEchoPulseUS(&echo_us) != 0U)
    {
        hcsr04_sample.valid = 1U;
        hcsr04_sample.echo_us = echo_us;
    }
    else
    {
        hcsr04_sample.valid = 0U;
        hcsr04_sample.echo_us = HCSR04_INVALID_PULSE_US;
    }

    hcsr04_sample.counter++;
}

int main(void)
{
    uint8_t delay_ms;

    (void)HCSR04_Init(&DDRC,
                      &PORTC,
                      PC3,
                      &DDRC,
                      &PINC,
                      PC2);

    (void)Servo_Init(&DDRB, &PORTB, PB3);
    (void)Servo_SetAngle(0U);

    DDRB |= (1U << SLAVE1_DC_LED_PIN);
    Slave1_SetDcState((uint8_t)PROTOCOL_DIRECTION_FORWARD, 0U);

    (void)I2C_Slave_Init(SLAVE1_I2C_ADDRESS);
    sei();

    while (1)
    {
        Slave1_ServiceI2C();
        Slave1_UpdateSensor();
        Slave1_ServiceI2C();

        for (delay_ms = 0U;
             delay_ms < SLAVE1_SAMPLE_INTERVAL_MS;
             delay_ms++)
        {
            Slave1_ServiceI2C();
            _delay_ms(1);
        }
    }
}
